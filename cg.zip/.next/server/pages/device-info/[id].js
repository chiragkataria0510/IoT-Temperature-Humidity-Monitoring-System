"use strict";
(() => {
var exports = {};
exports.id = 212;
exports.ids = [212];
exports.modules = {

/***/ 7475:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ DevicePage),
  "getServerSideProps": () => (/* binding */ getServerSideProps)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: external "@mui/material/Grid"
var Grid_ = __webpack_require__(5612);
var Grid_default = /*#__PURE__*/__webpack_require__.n(Grid_);
;// CONCATENATED MODULE: external "moment"
const external_moment_namespaceObject = require("moment");
var external_moment_default = /*#__PURE__*/__webpack_require__.n(external_moment_namespaceObject);
;// CONCATENATED MODULE: external "@mui/icons-material/FilterAlt"
const FilterAlt_namespaceObject = require("@mui/icons-material/FilterAlt");
var FilterAlt_default = /*#__PURE__*/__webpack_require__.n(FilterAlt_namespaceObject);
;// CONCATENATED MODULE: external "@mui/icons-material/Save"
const Save_namespaceObject = require("@mui/icons-material/Save");
var Save_default = /*#__PURE__*/__webpack_require__.n(Save_namespaceObject);
;// CONCATENATED MODULE: external "danfojs"
const external_danfojs_namespaceObject = require("danfojs");
;// CONCATENATED MODULE: external "mongoose"
const external_mongoose_namespaceObject = require("mongoose");
var external_mongoose_default = /*#__PURE__*/__webpack_require__.n(external_mongoose_namespaceObject);
;// CONCATENATED MODULE: ./models/Entries.js

const entriesSchema = new (external_mongoose_default()).Schema({
    deviceName: {
        type: String,
        required: true
    },
    devEUI: {
        type: String,
        required: true
    },
    temprature: {
        type: String,
        required: true
    },
    humidity: {
        type: String,
        required: true
    },
    timestamp: {
        type: Date,
        required: true
    }
});
const Entries = (external_mongoose_default()).models.Entries || external_mongoose_default().model("Entries", entriesSchema, "entries");
/* harmony default export */ const models_Entries = (Entries);

;// CONCATENATED MODULE: ./models/DeviceCalibration.js

const deviceCalibrationSchema = new (external_mongoose_default()).Schema({
    devEUI: {
        type: String,
        required: true,
        unique: true
    },
    temperature_calibration: {
        type: Number,
        required: true
    },
    humidity_calibration: {
        type: Number,
        required: true
    }
});
const DeviceCalibration = (external_mongoose_default()).models.DeviceCalibration || external_mongoose_default().model("DeviceCalibration", deviceCalibrationSchema, "device-calibration");
/* harmony default export */ const models_DeviceCalibration = (DeviceCalibration);

;// CONCATENATED MODULE: ./utils/db.js

const connection = {};
async function connect() {
    if (connection.isConnected) {
        console.log("already connected");
        return;
    }
    if ((external_mongoose_default()).connections.length > 0) {
        connection.isConnected = (external_mongoose_default()).connections[0].readyState;
        if (connection.isConnected === 1) {
            console.log("use previous connection");
            return;
        }
        await external_mongoose_default().disconnect();
    }
    const db = await external_mongoose_default().connect(process.env.MONGODB_URI, {
        useNewUrlParser: true,
        useUnifiedTopology: true,
        useCreateIndex: true
    });
    console.log("new connection");
    connection.isConnected = db.connections[0].readyState;
}
async function disconnect() {
    if (connection.isConnected) {
        // if (process.env.NODE_ENV === 'production') {
        //   await mongoose.disconnect();
        //   connection.isConnected = false;
        // } else {
        //   console.log('not disconnected');
        // }
        console.log("not disconnected");
    }
}
function convertDocToObj(doc) {
    doc._id = doc._id.toString();
    if (doc.timestamp) {
        doc.timestamp = doc.timestamp.toString();
    }
    return doc;
}
const db = {
    connect,
    disconnect,
    convertDocToObj
};
/* harmony default export */ const utils_db = (db);

// EXTERNAL MODULE: external "recharts"
var external_recharts_ = __webpack_require__(3655);
// EXTERNAL MODULE: external "@mui/material/TextField"
var TextField_ = __webpack_require__(6042);
var TextField_default = /*#__PURE__*/__webpack_require__.n(TextField_);
// EXTERNAL MODULE: external "@mui/material/Typography"
var Typography_ = __webpack_require__(7163);
var Typography_default = /*#__PURE__*/__webpack_require__.n(Typography_);
;// CONCATENATED MODULE: external "@mui/material/ListItem"
const ListItem_namespaceObject = require("@mui/material/ListItem");
var ListItem_default = /*#__PURE__*/__webpack_require__.n(ListItem_namespaceObject);
;// CONCATENATED MODULE: external "@mui/material/Stack"
const Stack_namespaceObject = require("@mui/material/Stack");
var Stack_default = /*#__PURE__*/__webpack_require__.n(Stack_namespaceObject);
;// CONCATENATED MODULE: external "@mui/material/ListItemText"
const ListItemText_namespaceObject = require("@mui/material/ListItemText");
var ListItemText_default = /*#__PURE__*/__webpack_require__.n(ListItemText_namespaceObject);
// EXTERNAL MODULE: external "@mui/material/Paper"
var Paper_ = __webpack_require__(1168);
var Paper_default = /*#__PURE__*/__webpack_require__.n(Paper_);
// EXTERNAL MODULE: external "axios"
var external_axios_ = __webpack_require__(2167);
var external_axios_default = /*#__PURE__*/__webpack_require__.n(external_axios_);
;// CONCATENATED MODULE: external "@mui/icons-material/NetworkCheck"
const NetworkCheck_namespaceObject = require("@mui/icons-material/NetworkCheck");
var NetworkCheck_default = /*#__PURE__*/__webpack_require__.n(NetworkCheck_namespaceObject);
;// CONCATENATED MODULE: external "@mui/icons-material/ArrowDownward"
const ArrowDownward_namespaceObject = require("@mui/icons-material/ArrowDownward");
var ArrowDownward_default = /*#__PURE__*/__webpack_require__.n(ArrowDownward_namespaceObject);
;// CONCATENATED MODULE: external "@mui/icons-material/Outbound"
const Outbound_namespaceObject = require("@mui/icons-material/Outbound");
var Outbound_default = /*#__PURE__*/__webpack_require__.n(Outbound_namespaceObject);
;// CONCATENATED MODULE: external "@mui/material/ListItemAvatar"
const ListItemAvatar_namespaceObject = require("@mui/material/ListItemAvatar");
var ListItemAvatar_default = /*#__PURE__*/__webpack_require__.n(ListItemAvatar_namespaceObject);
;// CONCATENATED MODULE: external "@mui/material/Avatar"
const Avatar_namespaceObject = require("@mui/material/Avatar");
var Avatar_default = /*#__PURE__*/__webpack_require__.n(Avatar_namespaceObject);
;// CONCATENATED MODULE: external "react-chartjs-2"
const external_react_chartjs_2_namespaceObject = require("react-chartjs-2");
// EXTERNAL MODULE: ./Layout/Layout.js + 9 modules
var Layout = __webpack_require__(1776);
// EXTERNAL MODULE: ./utils/DataStore.js
var DataStore = __webpack_require__(7820);
// EXTERNAL MODULE: external "notistack"
var external_notistack_ = __webpack_require__(3142);
// EXTERNAL MODULE: external "@mui/material/Box"
var Box_ = __webpack_require__(19);
var Box_default = /*#__PURE__*/__webpack_require__.n(Box_);
;// CONCATENATED MODULE: external "@mui/x-date-pickers/AdapterDateFns"
const AdapterDateFns_namespaceObject = require("@mui/x-date-pickers/AdapterDateFns");
;// CONCATENATED MODULE: external "@mui/x-date-pickers/LocalizationProvider"
const LocalizationProvider_namespaceObject = require("@mui/x-date-pickers/LocalizationProvider");
;// CONCATENATED MODULE: external "@mui/x-date-pickers/DatePicker"
const DatePicker_namespaceObject = require("@mui/x-date-pickers/DatePicker");
;// CONCATENATED MODULE: ./components/DatePickerComponent/DatePickerComponent.jsx








function DatePickerComponent({ startDate , SetStartDate , endDate , SetEndDate  }) {
    const { 0: pickerValue , 1: setPickerValue  } = (0,external_react_.useState)(external_moment_default()(startDate, "YYYY-MM-DD").add(0, "days").format("YYYY-MM-DDTHH:mm:ss"));
    function setValue(value) {
        setPickerValue(external_moment_default()(value, "YYYY-MM-DD").format("YYYY-MM-DD"));
        SetStartDate(external_moment_default()(value, "YYYY-MM-DD").add(0, "days").format("YYYY-MM-DD"));
        SetEndDate(external_moment_default()(value, "YYYY-MM-DD").add(1, "days").format("YYYY-MM-DD"));
    }
    return /*#__PURE__*/ jsx_runtime_.jsx(LocalizationProvider_namespaceObject.LocalizationProvider, {
        dateAdapter: AdapterDateFns_namespaceObject.AdapterDateFns,
        children: /*#__PURE__*/ jsx_runtime_.jsx((Box_default()), {
            m: 2,
            children: /*#__PURE__*/ jsx_runtime_.jsx(DatePicker_namespaceObject.DatePicker, {
                label: "Choose a date",
                views: [
                    "year",
                    "month",
                    "day"
                ],
                format: "DD-MM-YYYY",
                value: pickerValue,
                onChange: (newValue)=>{
                    setValue(external_moment_default()(newValue).format("YYYY-MM-DDTHH:mm:ss"));
                },
                renderInput: (params)=>/*#__PURE__*/ jsx_runtime_.jsx((TextField_default()), {
                        ...params
                    })
            })
        })
    });
}

// EXTERNAL MODULE: external "@mui/material/Button"
var Button_ = __webpack_require__(3819);
var Button_default = /*#__PURE__*/__webpack_require__.n(Button_);
// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(1853);
;// CONCATENATED MODULE: ./pages/device-info/[id].js






























function DevicePage({ tempArray , humArray , deviceCalibration  }) {
    const router = (0,router_.useRouter)();
    const { id  } = router.query;
    const { state  } = (0,external_react_.useContext)(DataStore/* DataStore */.K);
    const { userInfo  } = state;
    const currentDate = new Date();
    currentDate.setHours(0, 0, 0);
    (0,external_react_.useEffect)(()=>{
        if (!userInfo) {
            router.push("/login");
        }
        chartDataFilter();
    }, [
        userInfo,
        router
    ]);
    // console.log(deviceCalibration)
    const { enqueueSnackbar , closeSnackbar  } = (0,external_notistack_.useSnackbar)();
    const { 0: startDate , 1: SetStartDate  } = (0,external_react_.useState)(external_moment_default()(currentDate, "YYYY-MM-DDTHH:mm:ss").format("YYYY-MM-DD"));
    const { 0: endDate , 1: SetEndDate  } = (0,external_react_.useState)(external_moment_default()(currentDate, "YYYY-MM-DDTHH:mm:ss").add(1, "days").format("YYYY-MM-DD"));
    const { 0: current_humidity_calibration , 1: setCurrent_humidity_calibration  } = (0,external_react_.useState)(deviceCalibration?.humidity_calibration);
    const { 0: current_temperature_calibration , 1: setCurrent_temperature_calibration  } = (0,external_react_.useState)(deviceCalibration?.temperature_calibration);
    const { 0: tempMinArray , 1: setTempMinArray  } = (0,external_react_.useState)([]);
    const { 0: tempMaxArray , 1: setTempMaxArray  } = (0,external_react_.useState)([]);
    const { 0: tempAvgArray , 1: setTempAvgArray  } = (0,external_react_.useState)([]);
    const { 0: humMinArray , 1: setHumMinArray  } = (0,external_react_.useState)([]);
    const { 0: humMaxArray , 1: setHumMaxArray  } = (0,external_react_.useState)([]);
    const { 0: humAvgArray , 1: setHumAvgArray  } = (0,external_react_.useState)([]);
    async function chartDataFilter() {
        closeSnackbar();
        try {
            const { data  } = await external_axios_default().post(`${"https://chirag-chart.igscs.in/"}`, {
                start_date: startDate,
                end_date: endDate,
                deviceEUI: id
            });
            setTempMinArray(data.tempData.minArray);
            setTempMaxArray(data.tempData.maxArray);
            setTempAvgArray(data.tempData.avgArray);
            setHumMinArray(data.humData.minArray);
            setHumMaxArray(data.humData.maxArray);
            setHumAvgArray(data.humData.avgArray);
            setHumAvgArray(data.humData.avgArray);
            enqueueSnackbar("Filtered", {
                variant: "success"
            });
        } catch (e) {
            console.log(e);
        }
    }
    async function updateCallibration() {
        closeSnackbar();
        try {
            await external_axios_default().put("/api/device-calibration/set-device-calibration", {
                temperatureCalibration: current_temperature_calibration,
                humidityCalibration: current_humidity_calibration,
                devEUI: id
            });
            enqueueSnackbar("Updated Successfully", {
                variant: "success"
            });
        } catch (err) {
            enqueueSnackbar(err, {
                variant: "error"
            });
        }
    }
    // TABLE DATA
    const Temperaturedata = {
        labels: [
            "12 AM",
            "1 AM",
            "2 AM",
            "3 AM",
            "4 AM",
            "5 AM",
            "6 AM",
            "7 AM",
            "8 AM",
            "9 AM",
            "10 AM",
            "11 AM",
            "12 PM",
            "1PM",
            "2 PM",
            "3 PM",
            "4 PM",
            "5 PM",
            "6 PM",
            "7 PM",
            "8 PM",
            "9 PM",
            "10 PM",
            "11 PM"
        ],
        datasets: [
            {
                label: "Min Temperature",
                data: tempMinArray,
                borderColor: [
                    "red", 
                ],
                borderWidth: 1
            },
            {
                label: "Max Temperature",
                data: tempMaxArray,
                borderWidth: 1,
                borderColor: [
                    "blue", 
                ]
            },
            {
                label: "Average Temperature",
                data: tempAvgArray,
                borderWidth: 1,
                borderColor: [
                    "black", 
                ]
            }, 
        ]
    };
    const Humiditydata = {
        labels: [
            "12 AM",
            "1 AM",
            "2 AM",
            "3 AM",
            "4 AM",
            "5 AM",
            "6 AM",
            "7 AM",
            "8 AM",
            "9 AM",
            "10 AM",
            "11 AM",
            "12 PM",
            "1PM",
            "2 PM",
            "3 PM",
            "4 PM",
            "5 PM",
            "6 PM",
            "7 PM",
            "8 PM",
            "9 PM",
            "10 PM",
            "11 PM"
        ],
        datasets: [
            {
                label: "Min Humidity",
                data: humMinArray,
                borderColor: [
                    "red", 
                ],
                borderWidth: 1
            },
            {
                label: "Max Humidity",
                data: humMaxArray,
                borderWidth: 1,
                borderColor: [
                    "blue", 
                ]
            },
            {
                label: "Average Humidity",
                data: humAvgArray,
                borderWidth: 1,
                borderColor: [
                    "black", 
                ]
            }, 
        ]
    };
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Layout/* default */.Z, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx((Grid_default()), {
                style: {
                    color: "#34481F"
                },
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Typography_default()), {
                    sx: {
                        mb: 3
                    },
                    variant: "h3",
                    align: "center",
                    children: [
                        "Device EUI Number: ",
                        id
                    ]
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Stack_default()), {
                style: {
                    width: "100%"
                },
                alignItems: "center",
                justifyContent: "center",
                direction: "row",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(DatePickerComponent, {
                        startDate: startDate,
                        SetStartDate: SetStartDate,
                        endDate: endDate,
                        SetEndDate: SetEndDate
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx((Button_default()), {
                        onClick: ()=>chartDataFilter(),
                        endIcon: /*#__PURE__*/ jsx_runtime_.jsx((FilterAlt_default()), {}),
                        style: {
                            backgroundColor: "#FF5C93",
                            borderRadius: "1rem",
                            borderRadius: "1rem",
                            color: "white",
                            marginTop: "1rem",
                            marginBottom: "1rem",
                            padding: "0.7rem"
                        },
                        children: /*#__PURE__*/ jsx_runtime_.jsx("b", {
                            children: "  Click To Filter"
                        })
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Grid_default()), {
                sx: {
                    my: 3
                },
                container: true,
                spacing: 2,
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx((Grid_default()), {
                        item: true,
                        md: 6,
                        xs: 12,
                        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            style: {
                                border: "2px solid #34481F",
                                borderRadius: "1rem"
                            },
                            children: /*#__PURE__*/ jsx_runtime_.jsx(external_recharts_.ResponsiveContainer, {
                                className: "p-0",
                                width: "100%",
                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: "p-1",
                                            style: {
                                                backgroundColor: "#34481F",
                                                borderRadius: "1rem",
                                                color: "#fff",
                                                textAlign: "center"
                                            },
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("h5", {
                                                children: "Temperature Trend"
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            style: {
                                                padding: "3px"
                                            },
                                            children: /*#__PURE__*/ jsx_runtime_.jsx(external_react_chartjs_2_namespaceObject.Line, {
                                                height: 150,
                                                data: Temperaturedata
                                            })
                                        })
                                    ]
                                })
                            })
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx((Grid_default()), {
                        item: true,
                        md: 6,
                        xs: 12,
                        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            style: {
                                border: "2px solid #34481F",
                                borderRadius: "1rem"
                            },
                            children: /*#__PURE__*/ jsx_runtime_.jsx(external_recharts_.ResponsiveContainer, {
                                className: "p-0",
                                width: "100%",
                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: "p-1",
                                            style: {
                                                backgroundColor: "#34481F",
                                                borderRadius: "1rem",
                                                color: "#fff",
                                                textAlign: "center"
                                            },
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("h5", {
                                                children: "Humidity Trend"
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            style: {
                                                padding: "3px"
                                            },
                                            children: /*#__PURE__*/ jsx_runtime_.jsx(external_react_chartjs_2_namespaceObject.Line, {
                                                height: 150,
                                                data: Humiditydata
                                            })
                                        })
                                    ]
                                })
                            })
                        })
                    })
                ]
            }),
            userInfo && userInfo.isAdmin == true ? /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Grid_default()), {
                style: {
                    marginTop: "5rem"
                },
                container: true,
                spacing: 4,
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Grid_default()), {
                        component: (Paper_default()),
                        item: true,
                        sx: {
                            p: 3
                        },
                        md: 6,
                        xs: 12,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx((Grid_default()), {
                                sx: {
                                    my: 3
                                },
                                container: true,
                                children: /*#__PURE__*/ jsx_runtime_.jsx((Grid_default()), {
                                    item: true,
                                    xs: 12,
                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Grid_default()), {
                                        container: true,
                                        spacing: 2,
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx((Grid_default()), {
                                                item: true,
                                                xs: 4,
                                                children: /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                                    variant: "p",
                                                    sx: {
                                                        fontWeight: 700
                                                    },
                                                    children: "Temperature"
                                                })
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Grid_default()), {
                                                item: true,
                                                xs: 8,
                                                children: [
                                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)((ListItem_default()), {
                                                        children: [
                                                            /*#__PURE__*/ jsx_runtime_.jsx((ListItemAvatar_default()), {
                                                                children: /*#__PURE__*/ jsx_runtime_.jsx((Avatar_default()), {
                                                                    children: /*#__PURE__*/ jsx_runtime_.jsx((ArrowDownward_default()), {})
                                                                })
                                                            }),
                                                            tempArray[tempArray.length - 1] ? /*#__PURE__*/ jsx_runtime_.jsx((ListItemText_default()), {
                                                                primary: "Input",
                                                                secondary: (parseFloat(tempArray[tempArray.length - 1]) - parseFloat(current_temperature_calibration)).toFixed(2)
                                                            }) : /*#__PURE__*/ jsx_runtime_.jsx((ListItemText_default()), {
                                                                primary: "Input",
                                                                secondary: "--"
                                                            })
                                                        ]
                                                    }),
                                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)((ListItem_default()), {
                                                        children: [
                                                            /*#__PURE__*/ jsx_runtime_.jsx((ListItemAvatar_default()), {
                                                                children: /*#__PURE__*/ jsx_runtime_.jsx((Avatar_default()), {
                                                                    children: /*#__PURE__*/ jsx_runtime_.jsx((NetworkCheck_default()), {})
                                                                })
                                                            }),
                                                            /*#__PURE__*/ jsx_runtime_.jsx((TextField_default()), {
                                                                defaultValue: current_temperature_calibration,
                                                                onChange: (e)=>{
                                                                    setCurrent_temperature_calibration(e.target.value);
                                                                },
                                                                type: "number",
                                                                fullWidth: true,
                                                                id: "outlined-basic",
                                                                label: "Temperature Calibration",
                                                                variant: "outlined"
                                                            })
                                                        ]
                                                    }),
                                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)((ListItem_default()), {
                                                        children: [
                                                            /*#__PURE__*/ jsx_runtime_.jsx((ListItemAvatar_default()), {
                                                                children: /*#__PURE__*/ jsx_runtime_.jsx((Avatar_default()), {
                                                                    children: /*#__PURE__*/ jsx_runtime_.jsx((Outbound_default()), {})
                                                                })
                                                            }),
                                                            tempArray[tempArray.length - 1] ? /*#__PURE__*/ jsx_runtime_.jsx((ListItemText_default()), {
                                                                primary: "Output",
                                                                secondary: parseFloat(tempArray[tempArray.length - 1]).toFixed(2)
                                                            }) : /*#__PURE__*/ jsx_runtime_.jsx((ListItemText_default()), {
                                                                primary: "Output",
                                                                secondary: "--"
                                                            })
                                                        ]
                                                    })
                                                ]
                                            })
                                        ]
                                    })
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx((Grid_default()), {
                                item: true,
                                xs: 12,
                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Grid_default()), {
                                    container: true,
                                    spacing: 2,
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx((Grid_default()), {
                                            item: true,
                                            xs: 4,
                                            children: /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                                variant: "p",
                                                sx: {
                                                    fontWeight: 700
                                                },
                                                children: "Humidity"
                                            })
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Grid_default()), {
                                            item: true,
                                            xs: 8,
                                            children: [
                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)((ListItem_default()), {
                                                    children: [
                                                        /*#__PURE__*/ jsx_runtime_.jsx((ListItemAvatar_default()), {
                                                            children: /*#__PURE__*/ jsx_runtime_.jsx((Avatar_default()), {
                                                                children: /*#__PURE__*/ jsx_runtime_.jsx((ArrowDownward_default()), {})
                                                            })
                                                        }),
                                                        humArray[humArray.length - 1] ? /*#__PURE__*/ jsx_runtime_.jsx((ListItemText_default()), {
                                                            primary: "Input",
                                                            secondary: (parseFloat(humArray[humArray.length - 1]) - parseFloat(current_humidity_calibration)).toFixed(2)
                                                        }) : /*#__PURE__*/ jsx_runtime_.jsx((ListItemText_default()), {
                                                            primary: "Input",
                                                            secondary: "--"
                                                        })
                                                    ]
                                                }),
                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)((ListItem_default()), {
                                                    children: [
                                                        /*#__PURE__*/ jsx_runtime_.jsx((ListItemAvatar_default()), {
                                                            children: /*#__PURE__*/ jsx_runtime_.jsx((Avatar_default()), {
                                                                children: /*#__PURE__*/ jsx_runtime_.jsx((NetworkCheck_default()), {})
                                                            })
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime_.jsx((TextField_default()), {
                                                            defaultValue: current_humidity_calibration,
                                                            onChange: (e)=>{
                                                                setCurrent_humidity_calibration(e.target.value);
                                                            },
                                                            type: "number",
                                                            fullWidth: true,
                                                            label: "Humidity Calibration",
                                                            variant: "outlined"
                                                        })
                                                    ]
                                                }),
                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)((ListItem_default()), {
                                                    children: [
                                                        /*#__PURE__*/ jsx_runtime_.jsx((ListItemAvatar_default()), {
                                                            children: /*#__PURE__*/ jsx_runtime_.jsx((Avatar_default()), {
                                                                children: /*#__PURE__*/ jsx_runtime_.jsx((Outbound_default()), {})
                                                            })
                                                        }),
                                                        humArray[humArray.length - 1] ? /*#__PURE__*/ jsx_runtime_.jsx((ListItemText_default()), {
                                                            primary: "Output",
                                                            secondary: parseFloat(humArray[humArray.length - 1]).toFixed(2)
                                                        }) : /*#__PURE__*/ jsx_runtime_.jsx((ListItemText_default()), {
                                                            primary: "Output",
                                                            secondary: "--"
                                                        })
                                                    ]
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx((Button_default()), {
                                                    onClick: ()=>updateCallibration(),
                                                    endIcon: /*#__PURE__*/ jsx_runtime_.jsx((Save_default()), {}),
                                                    style: {
                                                        width: "100%",
                                                        backgroundColor: "#B8DCEA",
                                                        color: "#0B70B6",
                                                        marginTop: "1rem",
                                                        marginBottom: "1rem",
                                                        padding: "0.7rem"
                                                    },
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx("b", {
                                                        children: "   Save"
                                                    })
                                                })
                                            ]
                                        })
                                    ]
                                })
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx((Grid_default()), {
                        item: true,
                        lg: 6,
                        md: 6,
                        sm: 6,
                        xs: 12
                    })
                ]
            }) : /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {})
        ]
    });
}
async function getServerSideProps(ctx) {
    const { id  } = ctx.query;
    await utils_db.connect();
    const result = await models_Entries.find({
        devEUI: id
    }).lean();
    const deviceCalibration = await models_DeviceCalibration.find({
        devEUI: id
    }).lean();
    await utils_db.disconnect();
    if (result.length > 0) {
        const df = new external_danfojs_namespaceObject.DataFrame(result);
        const temperaturedf = df.column("temperature");
        const humiditydf = df.column("humidity");
        return {
            props: {
                tempArray: JSON.parse(JSON.stringify(temperaturedf.$data)),
                humArray: JSON.parse(JSON.stringify(humiditydf.$data)),
                deviceCalibration: JSON.parse(JSON.stringify(deviceCalibration.map(utils_db.convertDocToObj)))[0]
            }
        };
    } else {
        return {
            props: {
                tempArray: [],
                humArray: [],
                deviceCalibration: JSON.parse(JSON.stringify(deviceCalibration.map(utils_db.convertDocToObj)))[0]
            }
        };
    }
}


/***/ }),

/***/ 8130:
/***/ ((module) => {

module.exports = require("@material-ui/core");

/***/ }),

/***/ 8308:
/***/ ((module) => {

module.exports = require("@material-ui/core/styles");

/***/ }),

/***/ 4628:
/***/ ((module) => {

module.exports = require("@material-ui/core/styles/colorManipulator");

/***/ }),

/***/ 3349:
/***/ ((module) => {

module.exports = require("@material-ui/styles");

/***/ }),

/***/ 1883:
/***/ ((module) => {

module.exports = require("@mui/icons-material/AccountCircle");

/***/ }),

/***/ 9560:
/***/ ((module) => {

module.exports = require("@mui/icons-material/AddTask");

/***/ }),

/***/ 3622:
/***/ ((module) => {

module.exports = require("@mui/icons-material/ArrowBack");

/***/ }),

/***/ 1709:
/***/ ((module) => {

module.exports = require("@mui/icons-material/CellTowerSharp");

/***/ }),

/***/ 1050:
/***/ ((module) => {

module.exports = require("@mui/icons-material/DataObject");

/***/ }),

/***/ 4574:
/***/ ((module) => {

module.exports = require("@mui/icons-material/Inbox");

/***/ }),

/***/ 3365:
/***/ ((module) => {

module.exports = require("@mui/icons-material/Menu");

/***/ }),

/***/ 5711:
/***/ ((module) => {

module.exports = require("@mui/icons-material/SensorsSharp");

/***/ }),

/***/ 4428:
/***/ ((module) => {

module.exports = require("@mui/icons-material/StorageSharp");

/***/ }),

/***/ 752:
/***/ ((module) => {

module.exports = require("@mui/icons-material/TouchAppSharp");

/***/ }),

/***/ 19:
/***/ ((module) => {

module.exports = require("@mui/material/Box");

/***/ }),

/***/ 3819:
/***/ ((module) => {

module.exports = require("@mui/material/Button");

/***/ }),

/***/ 5612:
/***/ ((module) => {

module.exports = require("@mui/material/Grid");

/***/ }),

/***/ 1168:
/***/ ((module) => {

module.exports = require("@mui/material/Paper");

/***/ }),

/***/ 6042:
/***/ ((module) => {

module.exports = require("@mui/material/TextField");

/***/ }),

/***/ 7163:
/***/ ((module) => {

module.exports = require("@mui/material/Typography");

/***/ }),

/***/ 2167:
/***/ ((module) => {

module.exports = require("axios");

/***/ }),

/***/ 9003:
/***/ ((module) => {

module.exports = require("classnames");

/***/ }),

/***/ 6734:
/***/ ((module) => {

module.exports = require("js-cookie");

/***/ }),

/***/ 3280:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 2796:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 4957:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 744:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 5843:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 8524:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4406:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/page-path/denormalize-page-path.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 1751:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 6220:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/compare-states.js");

/***/ }),

/***/ 299:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-next-pathname-info.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 5789:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-next-pathname-info.js");

/***/ }),

/***/ 1897:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-bot.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 4567:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/path-has-prefix.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 1853:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 3142:
/***/ ((module) => {

module.exports = require("notistack");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 3655:
/***/ ((module) => {

module.exports = require("recharts");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [675,676,664,257,9,776], () => (__webpack_exec__(7475)));
module.exports = __webpack_exports__;

})();